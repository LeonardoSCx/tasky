// console.log('hello world');
// Example:
// window.DRAWIO_CONFIG= {"gridSteps": 10};